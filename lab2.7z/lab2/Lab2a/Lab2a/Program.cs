﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

struct variable
{
    public int num;
    public static int square(int num)
    {
        return num * num;
    }
    public static int cube(int num)
    {
        return num * num;
    }
}
namespace Lab2a
{
    class Program
    {
        static void Main(string[] args)
        {
            variable v1;
            int num;
            {
                Console.WriteLine("ebter the number");
                num = Convert.ToInt32(Console.ReadLine());
                int square, cube;
                int option;
                Console.WriteLine("enter operation");
                Console.WriteLine("1.square");
                Console.WriteLine("2.cube");
                Console.WriteLine("3.exit");
                option = Convert.ToInt32(Console.ReadLine());
                switch(option)
                {
                    case 1:
                        square = variable.square(num);
                        Console.WriteLine($"The square of{num} is {square}");
                        break;
                    case 2:
                        cube = variable.cube(num);
                        Console.WriteLine($"The cube of {num} is {cube}");
                        break;
                    case 3:
                        Console.WriteLine($"Thank you");
                        break;
                }
                Console.ReadKey();
            }
        }
    }
}
