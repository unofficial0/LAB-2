﻿namespace lab25
{
    internal class BookDemo
    {
    }
}