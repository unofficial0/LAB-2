﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab25
{
    class Program
    {
        static void Main(string[] args)
        {
            BookDemo book = new BookDemo();
            string[,] Book = new string[2, 4];
            for (int i = 0; i< Book.GetLength(0); i++)
                {
                Console.WriteLine("Enter the Book Title:");
                Book[i, 0] = Console.ReadLine();
                Console.WriteLine("Enter the Author:");
                Book[i, 1] = Console.ReadLine();
                Console.WriteLine("Enter the Publisher:");
                Book[i, 2] = Console.ReadLine();
                Console.WriteLine("Enter the price:");
                Book[i, 3] = Console.ReadLine();
            }
            Console.WriteLine("Entered details are:");
            for (int i = 0; i<Book.GetLength(0); i++)
            {
                Console.WriteLine("Title: {0}, Author:{1}, Publisher:{2}, Price:{3}", Book[i, 0], Book[i, 1], Book[i, 2], Book[i, 3]);
            }
            Console.ReadKey();
        }
    }
}
