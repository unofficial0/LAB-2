﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2c
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] city = new string[5];
            Console.WriteLine("enter city names");
            for (int i = 0; i< city.GetLength(0); i++)
            {
                city[i] = Console.ReadLine();

            }
            Console.WriteLine("city names are");
            for (int i = 0; i < city.GetLength(0); i++)
            {
                Console.WriteLine(city[i]);
            }
            Console.ReadKey();
        }
    }
}
